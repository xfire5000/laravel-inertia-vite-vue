<template>

</template>

<script>
export default {
    name: "Index",
    props: {departments: Array}
}
</script>

<style scoped>

</style>
